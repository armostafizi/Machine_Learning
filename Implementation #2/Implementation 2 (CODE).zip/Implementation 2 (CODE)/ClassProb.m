function [classProbs, classCounts] = ClassProb(labels)
    size = max(labels);
    classCounts = zeros(1, size);
    for i = transpose(labels)
        classCounts(i) = classCounts(i) + 1;      
    end
    classProbs = classCounts / sum(classCounts);
end

function [pyis] = Multinomial_Piys(data, labels, vocab, refinedVocab, deletedVocab, a)
    %a = 1;
    pyis = zeros(length(vocab),max(labels));
    for i = 1:length(data)
        pyis(data(i,2),labels(data(i,1))) = pyis(data(i,2),labels(data(i,1))) + data(i,3);
    end
    pyis(deletedVocab,:) = [];
    sm = sum(pyis);
    for i = 1 : max(labels)
        pyis(:,i) = (pyis(:,i) + a ) / ( sm(i) + (a * length(refinedVocab))) ;
    end
    %pyis = log(pyis);
end

function [pyis] = Bernouli_Piys(data, labels, vocab, classCounts)
    a = 2;
    %b = 20;
    %b = 61188;
    b = 2;
    pyis = zeros(length(vocab),max(labels));
    for i = 1:length(data)
        pyis(data(i,2),labels(data(i,1))) = pyis(data(i,2),labels(data(i,1))) + 1;   
    end
    
    for i = 1 : length(classCounts)
        pyis(:,i) = (pyis(:,i) + a - 1) / ( classCounts(i) + a + b - 2);
        %pyis(:,i) = (pyis(:,i)) / ( classCounts(i));
    end
end

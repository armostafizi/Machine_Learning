function [kkMat] = Confusion_Matrix(test_label, predict_label)
    kkMat = zeros(max(test_label));
    for i = 1 : length(test_label)
        kkMat(test_label(i), predict_label(i)) = kkMat(test_label(i), predict_label(i)) + 1;
    end
end
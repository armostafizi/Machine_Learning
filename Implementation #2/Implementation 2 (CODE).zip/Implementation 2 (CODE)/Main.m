%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LOADING DATA %%%%%%%%%
test_data = csvread('test.data');
train_data = csvread('train.data');
test_label = csvread('test.label');
train_label = csvread('train.label');
vocab = importdata('vocabulary.txt');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETER ESTIMATION

% Py MLE - BERNOULI and MULTINOKMIAL
[classProbs, classCounts] = ClassProb(train_label);

% Pi|y Laplase Smoothing - BERNOULI
bPyis = Bernouli_Piys(train_data, train_label, vocab, classCounts);

% Pi|y Laplase Smoothing - MULTINOMIAL
mPyis = Multinomial_Piys(train_data, train_label, vocab, refinedVocab, deletedVocab, 1);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PREDICTION
% BERNOULI
[bWordCount, bPredictProbability, bPredictLabel] = Bernouli_Predict(test_data, bPyis, classProbs, test_label, vocab);
bAccuracyRate = check(test_label, bPredictLabel);
bKKMat = Confusion_Matrix(test_label, bPredictLabel);

%Multinomial
refinedVocab = 1:length(vocab);
deletedVocab = [];
[mWordCount, mPredictProbability, mPredictLabel] = Multinomial_Predict(test_data, mPyis, classProbs, test_label, refinedVocab, deletedVocab, vocab);
mAccuracyRate = check(test_label, mPredictLabel);
mKKMat = Confusion_Matrix(test_label, mPredictLabel);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EXPERIMENT ON HYPER-PARAMETER
refinedVocab = 1:length(vocab);
deletedVocab = [];
rates = [];
i = 1;
for a = -5 : 0.1 : 0
    i
    i= i + 1;
    mPyis = Multinomial_Piys(train_data, train_label, vocab, refinedVocab, deletedVocab, 10 ^ a);
    [mWordCount, mPredictProbability, mPredictLabel] = Multinomial_Predict(test_data, mPyis, classProbs, test_label, refinedVocab, deletedVocab, vocab);
    mAccuracyRate = check(test_label, mPredictLabel)
    rates = [rates, mAccuracyRate]
end

plot(-5:0.1:0, rates, '--*')
title('Accuracy Rate vs. log \alpha, Hyper-parmeter')
xlabel('Log(\alpha)')
ylabel('Accuracy Rate (%)')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EXPERIMENT ON VOCABULARY MODIFICATION
%%%%%%%%%%%%%%%%%%%% WORD SELECTION

[refinedVocab, deletedVocab] = Class_Word(train_data, train_label, vocab);
mPyis = Multinomial_Piys(train_data, train_label, vocab, refinedVocab, deletedVocab, 1);
[classProbs, classCounts] = ClassProb(train_label);
[mWordCount, mPredictProbability, mPredictLabel] = Multinomial_Predict(test_data, mPyis, classProbs, test_label, refinedVocab, deletedVocab, vocab);
mAccuracyRate = check(test_label, mPredictLabel);
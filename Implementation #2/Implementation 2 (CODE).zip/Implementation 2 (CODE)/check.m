function [rate] = check (test_label, result_label)
    rate = 0;
    for i = 1 : length(test_label)
        if test_label(i) == result_label(i)
            rate = rate + 1;
        end
    end

    rate = rate / length(test_label) * 100;
end
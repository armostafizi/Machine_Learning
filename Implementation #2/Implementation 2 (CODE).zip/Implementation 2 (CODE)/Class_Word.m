function [refinedVocab, deletedVocab] = Class_Word(data, label, vocab)
    counts = zeros(length(vocab),max(label));
    for i = 1:length(data)
        counts(data(i,2),label(data(i,1))) = counts(data(i,2),label(data(i,1))) + data(i,3);
    end
    
%     notUsed = 0;
%     for i = 1:length(vocab)
%         if counts(i,:)==0
%             notUsed = notUsed + 1;
%             %vocab(i)
%         end
%     end
%     allUsed = 0;
%     for i = 1:length(vocab)
%         if counts(i,:) > 0
%             allUsed = allUsed + 1;
%             %vocab(i)
%         end
%     end
%     
    halfUsed = 0;
    refinedVocab = [];
    deletedVocab = [];
    for i = 1:length(vocab)
        zeroCount = 0;
        for j = 1: max(label)
            if counts(i,j) == 0
                zeroCount = zeroCount + 1;
            end
        end
        %if zeroCount >= 11 & zeroCount <= 20
        if zeroCount >= 1 & zeroCount <= 19
            halfUsed = halfUsed + 1;
            refinedVocab = [refinedVocab, i];
        else
            deletedVocab = [deletedVocab, i];
        end
    end
end
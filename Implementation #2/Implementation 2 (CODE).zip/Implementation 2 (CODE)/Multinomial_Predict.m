function [wordCounts, predictProbs, predictLabel] = Multinomial_Predict(test, pyis, classProbs, test_label, refinedVocab, deletedVocab, vocab)
    wordCounts = zeros(length(vocab),length(test_label));
    for i = 1 : length(test)
        wordCounts(test(i,2),test(i,1)) = wordCounts(test(i,2),test(i,1)) + test(i,3);
    end
    
    wordCounts(deletedVocab,:)=[];
    
    predictProbs = zeros(length(test_label),length(classProbs));
    for i = 1 : length(test_label)
        i
        for j = 1 : length(classProbs)
            sm = 0;
            for k = 1 : length(refinedVocab)
                sm = sm + ( wordCounts(k,i) * log(pyis(k,j)) );
            end
            predictProbs(i,j) = sm + log(classProbs(j));
        end
    end
    
    [M, predictLabel] = max(predictProbs,[],2);
    
end

function [wordCounts, predictProbs, predictLabel] = Bernouli_Predict(test, pyis, classProbs, test_label, vocab)
    wordCounts = zeros(length(vocab),length(test_label));
    for i = 1 : length(test)
        %wordCounts(test(i,2),test(i,1)) = wordCounts(test(i,2),test(i,1)) + test(i,3);
        wordCounts(test(i,2),test(i,1)) = 1;
    end
    
    predictProbs = zeros(length(test_label),length(classProbs));
    for i = 1 : length(test_label)
        i
        for j = 1 : length(classProbs)
            sm = 0;
            %p = 1;
            for k = 1 : length(vocab)
                sm = sm + ( wordCounts(k,i) * log(pyis(k,j)) ) + ( (1 - wordCounts(k,i)) * log( 1 - pyis(k,j) ) );
                %p = p * (( pyis(k,j)) ^ wordCounts(k,i) ) * ( ( 1 - pyis(k,j) ) ^ (1 - wordCounts(k,i)) );
            end
            predictProbs(i,j) = sm + log(classProbs(j));
            %predictProbs(i,j) = p * classProbs(j);
        end
    end
    
    [M, predictLabel] = max(predictProbs,[],2);
    
end

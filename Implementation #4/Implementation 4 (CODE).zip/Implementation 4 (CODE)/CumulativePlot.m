function [eigValCumulative] = CumulativePlot(relativeVars)

eigValCumulative = zeros(length(relativeVars),1);

for i = 1:length(relativeVars)
    eigValCumulative(i) = sum(relativeVars(1:i,1));
end
eigValCumulative = [0; eigValCumulative];

figure;
plot(eigValCumulative * 100, 'r-.');
title('Cumulative Varince over Prinicipal Components');
xlabel('PCs');
ylabel('Cumulative Variance (%)');
xlim([1, 256]);
ylim([0,100]);

end
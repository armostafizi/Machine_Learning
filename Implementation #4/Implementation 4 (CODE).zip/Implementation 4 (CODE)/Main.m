clear;
clc;

%%%%%%%%%%%%%%%%%%%%% READING DATA %%%%%%%%%%%%%%%%%%

rawData = csvread('digits79.csv');
labels = csvread('digitslabels.csv');

%%%%%%%%%%%%%%%%%%%%%% 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%

data = rawData;
accuracy = Kmeans(2, data, labels, 100)

%%% 50.71

%%%%%%%%%%%%%%%%%%%%%% 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%

newData = Centralize(rawData);
[eigVals, eigVectors] = Eigs(newData);

relativeVars = RelativeVars(eigVals);
eigValCumulative = CumulativePlot(relativeVars);

%%% at least 23 features for 80% AND at least 43 features for 90%

%%%%%%%%%%%%%%%%%%%%%%%%%% 3 %%%%%%%%%%%

newData = Centralize(rawData);
[eigVals, eigVectors] = Eigs(newData);

ReducedGraphs(rawData, eigVectors, labels)

features = 1:3;
accuracies = [];
for feats = features
    feats
    
    data = rawData * (eigVectors(:,1:feats));
    
    accuracy = Kmeans(2, data, labels, 100);
    accuracies = [accuracies, mean(accuracy)];
end
%%% [50.21,50.68,50.70]

%%%%%%%%%%%%%%%%%%%%% 4 %%%%%%%%%%%%%%%%

rawData = csvread('digits79.csv');
labels = csvread('digitslabels.csv');
sevens = rawData(find(labels == 7),:);
m7 = mean(sevens);
nines = rawData(find(labels == 9),:);
m9 = mean(nines);

for i = 1:size(sevens,1)
    newSevens(i,:) = sevens(i,:) - m7;
end
for i = 1:size(nines,1)
    newNines(i,:) = nines(i,:) - m9;
end

s = newSevens' * newSevens + newNines' * newNines;

w = inv(s) * (m7 - m9)'; 

projectedData = rawData * w;
data = projectedData * 10^5;

realSevens = projectedData(find(labels == 7),:);
realNines = projectedData(find(labels == 9),:);
figure;
plot(realSevens(:,1),zeros(length(realSevens),1),'b.');
ylim([0, 100]);
hold on;
plot(realNines(:,1),ones(length(realNines),1),'r.');
ylim([0, 100]);
title('Visualization of 1-D Projected Data - TRUE Labels');
xlabel('First Dimension');

[accuracy, predictedLabels] = Kmeans(2, data, labels, 1);

predictedSevens = projectedData(find(predictedLabels == 7),:);
predictedNines = projectedData(find(predictedLabels == 9),:);
figure;
plot(predictedSevens(:,1),zeros(length(predictedSevens),1),'b.');
ylim([0, 100]);
hold on;
plot(predictedNines(:,1),ones(length(predictedNines),1),'r.');
ylim([0, 100]);
title('Visualization of 1-D Projected Data - PREDICTED Labels');
xlabel('First Dimension');

%%% 99.14%

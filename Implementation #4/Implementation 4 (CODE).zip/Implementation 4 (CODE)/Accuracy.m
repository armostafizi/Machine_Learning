function accuracy = Accuracy(predictions, classLabels, labels)
    predictedLabels = predictions;
    for i = 1:length(predictions)
        predictedLabels(i) = classLabels(predictions(i));
    end

    corrects = sum(predictedLabels == labels);
    accuracy = corrects / length(labels);

end
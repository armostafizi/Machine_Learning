function ind = Label(data, means)
    dists = zeros(size(means,1),1);
    for i = 1:size(means, 1)
        dists(i) = sum((data - means(i,:)).^2);
    end
    [m, ind] = min(dists);

end
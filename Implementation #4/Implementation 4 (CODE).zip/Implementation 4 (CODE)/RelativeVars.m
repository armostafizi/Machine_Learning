function relativeVars = RelativeVars(eigVals)

sm = sum(eigVals);
eigVals(:,1)=eigVals(:,1) / sm;

varPercents = eigVals * 100;
figure;
bar(1:100,varPercents(1:100));
title('Variance vs. Prinicipal Components');
xlabel('PCs');
ylabel('Variance(%)');
axis([0 60 0 20]);

relativeVars = eigVals;

end
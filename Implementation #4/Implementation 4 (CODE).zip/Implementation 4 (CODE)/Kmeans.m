function [accuracy, predictedLabels] = Kmeans(k,data, labels, iterations)

mins = round(min(data,[],1));
maxs = round(max(data,[],1));


accuracies = [];
predictedLabelsS = [];

for iteration = 1:iterations
    
    inits = [];
    for i = 1:k
        init = [];
        for j = 1:length(mins)
            init = [init, randi([mins(j), maxs(j)])]; 
        end
        inits = [inits; init];
    end

    means = inits;
    oldPredictions = [];
    
    while 1

        predictions = [];
        for i = 1:size(data,1)
            predictions = [predictions; Label(data(i,:), means)];
        end
        
        if isequal(predictions, oldPredictions)
            break
        end
        
        oldPredictions = predictions;
        
        classLabels = zeros(k,1);
        for i = 1:k
           classLabels(i) = mode(labels(find(predictions == i))); 
        end

        newMeans = means;
        for i = 1:k
            subData = data(find(predictions == i),:);
            newMeans(i,:) = mean(subData,1);
        end

        means = newMeans;
        accuracy = Accuracy(predictions, classLabels, labels);
    end  

    accuracies = [accuracies, accuracy];
    predictedLabels = classLabels(predictions);
    
end

accuracy = mean(accuracies);

end
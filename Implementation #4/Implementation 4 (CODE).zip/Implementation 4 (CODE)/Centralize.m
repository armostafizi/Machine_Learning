function newData = Centralize(data)
    xbar = mean(data,1);
    stdev = std(data,1);
    newData = data;
    for i = 1:size(data,1)
        %newData(i,:) = (data(i,:) - xbar) ./ stdev;
        newData(i,:) = (data(i,:) - xbar);
    end
end
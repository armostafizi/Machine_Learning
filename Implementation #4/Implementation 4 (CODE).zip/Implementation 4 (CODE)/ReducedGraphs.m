function ReducedGraphs(rawData, eigVectors, labels)

%%% ONE dimension
data = rawData * (eigVectors(:,1));
realSevens = data(find(labels == 7),:);
realNines = data(find(labels == 9),:);
figure;
plot(realSevens(:,1),zeros(length(realSevens),1),'b.');
ylim([0, 100]);
hold on;
plot(realNines(:,1),ones(length(realNines),1),'r.');
ylim([0, 100]);
title('Visualization of 1-D Projected Data - TRUE Labels');
xlabel('First Dimension');

[accuracy, predictedLabels] = Kmeans(2, data, labels, 1);
predictedSevens = data(find(predictedLabels == 7),:);
predictedNines = data(find(predictedLabels == 9),:);
figure;
plot(predictedSevens(:,1),zeros(length(predictedSevens),1),'b.');
ylim([0, 100]);
hold on;
plot(predictedNines(:,1),ones(length(predictedNines),1),'r.');
ylim([0, 100]);
title('Visualization of 1-D Projected Data - PREDICTED Labels');
xlabel('First Dimension');

%%% TWO Dimensionn
data = rawData * (eigVectors(:,1:2));
figure;
gscatter(data(:,1),data(:,2),labels,'br','..');
title('Visualization of 2-D Projected Data - TRUE Labels');
xlabel('First Dimension');
ylabel('Second Dimension');
[accuracy, predictedLabels] = Kmeans(2, data, labels, 1);
figure;
gscatter(data(:,1),data(:,2),predictedLabels,'br','..');
title('Visualization of 2-D Projected Data - PREDICTED Labels');
xlabel('First Dimension');
ylabel('Second Dimension');

%%% THREE Dimension
data = rawData * (eigVectors(:,1:3));
realSevens = data(find(labels == 7),:);
realNines = data(find(labels == 9),:);
figure;
scatter3(realSevens(:,1),realSevens(:,2),realSevens(:,3),'b.');
hold on;
scatter3(realNines(:,1),realNines(:,2),realNines(:,3),'r.');
title('Visualization of 3-D Projected Data - TRUE Labels');
xlabel('First Dimension');
ylabel('Second Dimension');
zlabel('Third Dimension');
[accuracy, predictedLabels] = Kmeans(2, data, labels, 1);
predictedSevens = data(find(predictedLabels == 7),:);
predictedNines = data(find(predictedLabels == 9),:);
figure;
scatter3(predictedSevens(:,1),predictedSevens(:,2),predictedSevens(:,3),'b.');
hold on;
scatter3(predictedNines(:,1),predictedNines(:,2),predictedNines(:,3),'r.');
title('Visualization of 3-D Projected Data - PREDICTED Labels');
xlabel('First Dimension');
ylabel('Second Dimension');
zlabel('Third Dimension');
end
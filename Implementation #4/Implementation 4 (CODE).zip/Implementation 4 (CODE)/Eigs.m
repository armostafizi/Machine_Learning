function [eigVals, eigVectors] = Eigs(newData)

cv = (1 / size(newData,1)) * newData' * newData;
[vectors, eigVals] = eig(cv);
eigVals = diag(eigVals);
[eigVals, inds] = sortrows(eigVals,-1);
eigVectors = vectors(:,inds);

end
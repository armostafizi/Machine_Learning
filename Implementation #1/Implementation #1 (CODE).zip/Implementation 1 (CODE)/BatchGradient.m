function [count,gr_mags,w] = BatchGradient(train_x,train_y,alpha,lambda)
s = size(train_x);
w=zeros(1,s(2));

gr_mags = [];
count = 0;
gr_mag = 10;
while gr_mag > 0.1 & count < 10000
    
    %Gr_mag
    
    Gr = (( train_x * (transpose(w))) - train_y);
    Gr = bsxfun(@times,Gr,train_x);
    Gr = sum(Gr);
    Gr = Gr + (lambda * w);
    w = w - (alpha * Gr);
    count = count + 1;
    gr_mag = norm(Gr);
    if gr_mag > 200
        count = 10000;
    end
    gr_mags = [gr_mags, gr_mag];
    
end
grmagsize = size(gr_mags);
Nans = 10000 - grmagsize(2);
for i=1:Nans
    gr_mags = [gr_mags, NaN];
end

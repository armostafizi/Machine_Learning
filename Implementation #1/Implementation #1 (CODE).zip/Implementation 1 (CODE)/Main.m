clear
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Initializing %%%%%%%%%%%%%%%%%%%%

% Reading the files

train = csvread('train.csv');
test = csvread('test.csv');

[ train_rows , train_cols ] = size(train);
[ test_rows , test_cols ] = size(test);

% Adjusting features values to 0-1 range

adj_train = train;
for i = 2:train_cols
    mx = max(train(:,i));
    mn = min(train(:,i)); 
    adj_train(:,i)=( train(:,i) - mn ) / (mx - mn);
end


adj_test = test;
for i = 2:test_cols
    mx = max(test(:,i));
    mn = min(test(:,i)); 
    adj_test(:,i)=( test(:,i) - mn ) / (mx - mn);
end

%Dividing parts

train_x = adj_train(:,1:train_cols - 1);
test_x = adj_test(:,1:test_cols - 1);

train_y = adj_train(:,train_cols);
test_y = adj_test(:,test_cols);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MAIN %%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%   1   %%%%%%%%%%%%%%%%

magnitudeList = [];
counts = [];
log_alphas = -6:0.1:0;
alphas = 10.^log_alphas;
for alpha = alphas
    [count,magnitudes,w] = BatchGradient(train_x,train_y,alpha,1);
    magnitudeList = [magnitudeList; magnitudes];
    counts = [counts, count];
end

plot(log_alphas,counts,'-*');
xlabel('Log(Learning Rate) - Alpha');
ylabel('Time to Convergence - # of Trials');
title('Time to Convergence vs. Log(Learning Rate)')
%Best Alpha = 0.0016

plot(magnitudeList(33,1:1000));
xlabel('# of Trials');
ylabel('|Gradient|');
title('Learning Curve');
%hold on;
plot(magnitudeList(15,1:1000));
%hold on;
plot(magnitudeList(5,1:1000));

%%%%%%%%%%%%%%%%%%%%%%%%%%%  2  %%%%%%%%%%%
SSEs_test = [];
SSEs_train = [];
log_lambdas = -3:0.1:3;
lambdas = 10.^log_lambdas;
lambda_counts = [];
for lambda = lambdas
    [lambda_count,m,w] = BatchGradient(train_x,train_y,0.0016,lambda);
    lambda_counts = [lambda_counts, lambda_count];
    [SSE_train, SSE_test] = SSE_Calculator(w,train_x,test_x,train_y,test_y);
    SSEs_test = [SSEs_test, SSE_test];
    SSEs_train = [SSEs_train, SSE_train];
end


plot(log_lambdas(1,1:49), SSEs_test(1,1:49),'-*');
xlabel('Log(Regularization Coefficient) - Lambda');
ylabel('SSE');
title('SSE of TESTING data')
plot(log_lambdas(1,1:49), SSEs_train(1,1:49),'-*');
xlabel('Log(Regularization Coefficient) - Lambda');
ylabel('SSE');
title('SSE of TRAINING data')


%%%%%%%%%%%%%%%%%%%%%%%%%%%  3  %%%%%%%%%%%%%%


log_lambdas = -3:0.1:3;
lambdas = 10.^log_lambdas;

cross_validation_SSEs = [];

for lambda = lambdas
    cross_validation_sse = 0;
    for i=0:9
        temp_train_x = train_x;
        temp_train_y = train_y;

        validation_set_x = temp_train_x( i*10 + 1 : i*10 + 10,:);
        validation_set_y = temp_train_y( i*10 + 1 : i*10 + 10,:);

        temp_train_x( i*10 + 1 : i*10 + 10,:)=[];
        temp_train_y( i*10 + 1 : i*10 + 10,:)=[];

        training_set_x = temp_train_x;
        training_set_y = temp_train_y;


        [lambda_count,m,w] = BatchGradient(training_set_x,training_set_y,0.0016,lambda);
        sse_test = Cross_Validation_SSE_Calculator(w,validation_set_x,validation_set_y);

        cross_validation_sse = cross_validation_sse + sse_test;   

    end
    
    cross_validation_SSEs = [cross_validation_SSEs, cross_validation_sse];
    
end



plot(log_lambdas(1,1:49),cross_validation_SSEs(1,1:49),'-*');
xlabel('Log(Regularization Coefficient) - Lambda');
ylabel('SSE');
title('Cross-Validation SSE')

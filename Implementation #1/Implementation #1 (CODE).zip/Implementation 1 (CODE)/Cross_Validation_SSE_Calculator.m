function sse_test = Cross_Validation_SSE_Calculator(w,test_x,test_y)

    sse_test = (( test_x * (transpose(w))) - test_y).^2;
    sse_test = sum(sse_test);
    
end

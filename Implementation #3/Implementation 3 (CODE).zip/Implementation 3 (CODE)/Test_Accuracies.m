function [accuracies] = Test_Accuracies (train_x,train_y,test_x,test_y)
    s = size(train_x);
    accuracies = [];
    for i = 1:s(2)
       [zeroMode, nonZeroMode] = Modes(train_x(:,i), train_y);
       x = test_x(:,i);
       y = test_y;
       
       zeroSet = y(find(~x),:);
       correctZeroCounts = sum(zeroSet(:) == zeroMode);
       
       nonZeroSet = y(find(x),:);
       correctNonZeroCounts = sum(nonZeroSet(:) == nonZeroMode);
       
       accuracy = (correctZeroCounts + correctNonZeroCounts) / (length(test_y));
       accuracies = [accuracies accuracy];
    end



end
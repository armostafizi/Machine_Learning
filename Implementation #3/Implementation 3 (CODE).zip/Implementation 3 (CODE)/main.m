clear all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% LOADING DATA %%%%%%%%%
train = csvread('SPECT-train.csv');
test = csvread('SPECT-test.csv');

train_y = train(:,1);
test_y = test(:,1);
train_x = train(:,2:end);
test_x = test(:,2:end);

clear test train;

%%%%%%%%%%%%%%%%%%%% DECISION STUB %%%%%%%%%%%%%

[InfoGains, trainAccuracies] = Decision_Stump(train_x,train_y);
[maxInfoGain, maxInfoFeature] = max(InfoGains); %Feature 13 is the best
plot(InfoGains,'g*');
title('Information Gain vs. Feature Index');
xlabel('Feature Index');
ylabel('Information Gain');

[maxTrainAccuracy, maxTrainAccuracyFeature] = max(trainAccuracies);
figure;
plot(trainAccuracies,'b*');
title('Accuracy of Training Set');
xlabel('Feature Index');
ylabel('Accuracy (Training Set)');

% Testset Accuracy:

[testAccuracies] = Test_Accuracies(train_x,train_y,test_x,test_y);
[maxTestAccuracy, maxTestAccuracyFeature] = max(testAccuracies);

figure;
plot(testAccuracies,'r*');
title('Accuracy of Testing Set');
xlabel('Feature Index');
ylabel('Accuracy (Testing Set)');

%%%%%%%%%%%%%%%%%%%% BAGGING %%%%%%%%%%%%%%%%%%%%%%%%%%%%
sizes = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50];
sizes = 5:30;
trainAcs = [];
testAcs = [];
featuresUsed = [];

for s = sizes
   s
   testAccuracies = [];
   trainAccuracies = [];
   feats = zeros(1, 22);
   for i = 1:100
       
       testPredictions = [];
       trainPredictions = [];
       
       for j = 1:s
           [train_sample_x, train_sample_y] = MakeSample(train_x, train_y);
           [InfoGains, ] = Decision_Stump(train_sample_x,train_sample_y);
           [maxInfoGain, maxInfoFeature] = max(InfoGains);
           feats(maxInfoFeature) = feats(maxInfoFeature) + 1;
           [zeroMode, nonZeroMode] = Modes(train_sample_x(:,maxInfoFeature), train_sample_y);
           testPredictions = [testPredictions, Predict(zeroMode, nonZeroMode, test_x(:,maxInfoFeature), test_y)];
           trainPredictions = [trainPredictions, Predict(zeroMode, nonZeroMode, train_x(:,maxInfoFeature), train_y)];        
       end
       testAccuracy = Test_Accuracy(testPredictions, test_y);
       trainAccuracy = Test_Accuracy(trainPredictions, train_y);
   
       testAccuracies = [testAccuracies testAccuracy];
       trainAccuracies = [trainAccuracies trainAccuracy];
   end
   
   testAcs = [testAcs; testAccuracies];
   trainAcs = [trainAcs; trainAccuracies];
      
   featuresUsed = [featuresUsed; feats];
end

figure;
plot(sizes, mean(transpose(testAcs)), '-r.');
title('Accuracy of Testing Set vs. Ensemble Size');
xlabel('Ensemble Size');
ylabel('Accuracy (Testing Set)');

figure;
plot(sizes, mean(transpose(trainAcs)), '-b.');
title('Accuracy of Training Set vs. Ensemble Size');
xlabel('Ensemble Size');
ylabel('Accuracy (Training Set)');

figure;
bar(featuresUsed(1,:));
title('Feature Usage - Ensemble Size = 5');
xlabel('Feature Index');
ylabel('Frequency');

figure;
bar(featuresUsed(13,:));
title('Feature Usage - Ensemble Size = 17');
xlabel('Feature Index');
ylabel('Frequency');

figure;
bar(featuresUsed(26,:));
title('Feature Usage - Ensemble Size = 30');
xlabel('Feature Index');
ylabel('Frequency');

%%%%%%%%%%%%%%%%%%%%% BOOSTING %%%%%%%%%%%%%%%%%

trainAcs = [];
testAcs = [];

weights = zeros(length(train_y),1);
weights(:) = 1/length(train_y);
alphas = [];
testPredictions = [];
trainPredictions = [];
errors = [];
featuresUsed = [];

for i = 1:100
    i
    [train_x_adaboost, train_y_adaboost] = AdaboostResample(train_x, train_y, weights);
    [InfoGains, trainAccuracies] = Decision_Stump(train_x_adaboost,train_y_adaboost);
    [maxInfoGain, maxInfoFeature] = max(InfoGains);
    featuresUsed = [featuresUsed; [i, maxInfoFeature]];
    trainAdaboostAccuracy = trainAccuracies(maxInfoFeature);
    error = 1 - trainAdaboostAccuracy;
    errors = [errors, error];
    alpha = 0.5 * (log((1 - error) / error));
    alphas = [alphas, alpha];
    [zeroMode, nonZeroMode] = Modes(train_x_adaboost(:,maxInfoFeature), train_y_adaboost);
    trainPrediction = Predict(zeroMode, nonZeroMode, train_x(:,maxInfoFeature), train_y);
    testPrediction = Predict(zeroMode, nonZeroMode, test_x(:,maxInfoFeature), test_x);
    weights = UpdateWeights(weights,train_y, trainPrediction, alpha);
    weights = weights / sum(weights);
    
    testPredictions = [testPredictions, testPrediction];
    trainPredictions = [trainPredictions, trainPrediction];
    
    testFinalPrediction = WeightedPrediction(testPredictions, alphas);
    trainFinalPrediction = WeightedPrediction(trainPredictions, alphas);
    
    testAccuracy = Test_Accuracy(testFinalPrediction, test_y);
    trainAccuracy = Test_Accuracy(trainFinalPrediction, train_y);
    
    testAcs = [testAcs testAccuracy];
    trainAcs = [trainAcs trainAccuracy];
    
end


figure;
plot(testAcs, '-r.');
title('Accuracy of Testing Set vs. Ensemble Size');
xlabel('Ensemble Size');
ylabel('Accuracy (Testing Set)');

figure;
plot(trainAcs, '-b.');
title('Accuracy of Training Set vs. Ensemble Size');
xlabel('Ensemble Size');
ylabel('Accuracy (Training Set)');

figure;
plot(errors);
title('Error, \epsilon, vs. Ensemble Size');
xlabel('Ensemble Size');
ylabel('Error, \epsilon');
figure;
plot(alphas);
title('Alpha, \alpha, vs. Ensemble Size');
xlabel('Ensemble Size');
ylabel('Alpha, \alpha');
figure;
scatter(featuresUsed(:,1), featuresUsed(:,2),'filled');
title('Features Used');
xlabel('Ensemble Size');
ylabel('Feature Index');

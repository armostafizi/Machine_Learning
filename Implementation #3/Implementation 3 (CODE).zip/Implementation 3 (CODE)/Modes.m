function [zeroSetMode, nonZeroSetMode] = Modes(x,y)
    
    zeroSet = y(find(~x));
    nonZeroSet = y(find(x));
    
    zeroSetMode = mode(zeroSet);
    nonZeroSetMode = mode(nonZeroSet);
    
end
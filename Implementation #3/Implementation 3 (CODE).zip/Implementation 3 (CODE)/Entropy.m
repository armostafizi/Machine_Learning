function [entropy] = Entropy(s)
    l = length(s);
    pZeros = length(find(~s)) / l;
    pNonZeros = length(find(s)) / l;
    
    entropy = - (pZeros * log2(pZeros)) - (pNonZeros * log2(pNonZeros));
    
    if isnan(entropy)
        entropy = 0;
    end
end
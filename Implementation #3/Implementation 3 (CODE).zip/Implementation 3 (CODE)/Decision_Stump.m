function [infoGains, accuracies] = Decision_Stump(xs,y)
    s = size(xs);
    infoGains = [];
    accuracies = [];
    for i = 1: s(2)
        infoGain = Info_Gain(xs(:,i),y);
        accuracy = Accuracy(xs(:,i),y);
        infoGains = [infoGains infoGain];
        accuracies = [accuracies accuracy];
    end
end

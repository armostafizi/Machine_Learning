function [accuracy] = Accuracy(x,y)
    
    zeroSet = y(find(~x));
    nonZeroSet = y(find(x));
    
    zeroSetMode = mode(zeroSet);
    nonZeroSetMode = mode(nonZeroSet);
    
    correctCountZeroSet = sum(zeroSet(:) == zeroSetMode);
    correctCountNonZeroSet = sum(nonZeroSet(:) == nonZeroSetMode);
    
    accuracy = (correctCountZeroSet + correctCountNonZeroSet) / length(y);
    
end
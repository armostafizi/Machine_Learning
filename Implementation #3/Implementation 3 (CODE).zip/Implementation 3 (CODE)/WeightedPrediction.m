function [finalPrediction] = WeightedPrediction(predictions, alphas)
    sz= size(predictions);
    finalPrediction = zeros(sz(1),1);
    for i = 1:sz(1)
        row = predictions(i,:);
        sumZero = sum(alphas(find(row==0)));
        sumOne = sum(alphas(find(row==1)));
        if sumZero > sumOne
            finalPrediction(i,1) = 0;
        else
            finalPrediction(i,1) = 1;
    end
end
function [accuracy] = Test_Accuracy (predictions, y)
    finalPredictions = mode(predictions, 2);
    falseCounts = sum(abs(finalPredictions - y));
    
    accuracy = 1 - (falseCounts / length(y));
end
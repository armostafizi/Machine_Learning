function [prediction] = Predict(zeroMode, nonZeroMode, x, y)
    prediction = zeros (length(y),1);
    prediction(find(~x),1) = zeroMode;
    prediction(find(x),1) = nonZeroMode;
end
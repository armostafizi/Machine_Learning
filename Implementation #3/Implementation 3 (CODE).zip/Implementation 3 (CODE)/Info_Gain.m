function [infoGain] = Info_Gain(x,y)
    entropyY = Entropy(y);
    
    zeroSet = y(find(~x));
    nonZeroSet = y(find(x));
    
    entropyZeroSet = Entropy(zeroSet);
    entropyNonZeroSet = Entropy(nonZeroSet);

    
    pZeroSet = length(zeroSet) / length(y);
    pNonZeroSet = length(nonZeroSet) / length(y);
    
    infoGain = entropyY - (pZeroSet * entropyZeroSet) - (pNonZeroSet * entropyNonZeroSet);

end
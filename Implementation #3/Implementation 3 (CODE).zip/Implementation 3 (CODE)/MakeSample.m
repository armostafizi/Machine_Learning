function [train_sample_x train_sample_y] = MakeSample (train_x, train_y)
    train_sample_x = [];
    train_sample_y = [];
    for j = 1:length(train_y)
        index = randi(length(train_y));
        train_sample_x = [train_sample_x; train_x(index,:)];
        train_sample_y = [train_sample_y; train_y(index,:)];
    end
end

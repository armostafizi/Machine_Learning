function [train_x_adaboost, train_y_adaboost] = AdaboostResample (train_x, train_y, weights)
    multiplier = 1 / min(weights);
    repetitions = ceil(weights * multiplier);
    train_x_adaboost = [];
    train_y_adaboost = [];
    for i = 1:length(train_y)
        for j = 1:repetitions(i)
            train_x_adaboost = [train_x_adaboost; train_x(i,:)];
            train_y_adaboost = [train_y_adaboost; train_y(i,:)];
        end
    end
end
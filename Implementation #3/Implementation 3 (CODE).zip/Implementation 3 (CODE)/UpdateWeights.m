function [newWeights] = UpdateWeights(weights, train_y, trainPredict, alpha)
    newWeights = zeros(length(weights),1);
    for i = 1:length(weights)
        if train_y(i) == trainPredict(i)
            newWeights(i) = weights(i) * exp(-alpha);
        else
            newWeights(i) = weights(i) * exp(alpha);
        end
    end
end